import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import test from "node:test";
import ts from "typescript";

const root = new URL("..", import.meta.url).pathname;

function tsxFiles(directory) {
  return fs.readdirSync(directory, { withFileTypes: true }).flatMap((entry) => {
    const location = path.join(directory, entry.name);
    if (entry.isDirectory()) return tsxFiles(location);
    return entry.name.endsWith(".tsx") ? [location] : [];
  });
}

test("every visible button has an action, submit behavior, or disabled state", () => {
  const inert = [];
  for (const file of tsxFiles(path.join(root, "app"))) {
    const source = fs.readFileSync(file, "utf8");
    const tree = ts.createSourceFile(
      file,
      source,
      ts.ScriptTarget.Latest,
      true,
      ts.ScriptKind.TSX,
    );
    function inspect(node) {
      if (ts.isJsxOpeningElement(node) || ts.isJsxSelfClosingElement(node)) {
        const name = node.tagName.getText(tree);
        if (name === "button" || name === "Button") {
          const attributes = node.attributes.properties.map((item) =>
            item.name?.getText(tree),
          );
          const type = node.attributes.properties
            .find((item) => item.name?.getText(tree) === "type")
            ?.initializer?.getText(tree);
          const actionable =
            attributes.includes("onClick") ||
            attributes.includes("disabled") ||
            attributes.includes("asChild") ||
            /submit/.test(type || "");
          if (!actionable) {
            const line = tree.getLineAndCharacterOfPosition(node.pos).line + 1;
            inert.push(`${path.relative(root, file)}:${line}`);
          }
        }
      }
      ts.forEachChild(node, inspect);
    }
    inspect(tree);
  }
  assert.deepEqual(inert, []);
});

test("route map exposes address search, optimization, and animated itinerary", () => {
  const map = fs.readFileSync(path.join(root, "app/components/route-map.tsx"), "utf8");
  const css = fs.readFileSync(path.join(root, "app/globals.css"), "utf8");
  const api = fs.readFileSync(path.join(root, "backend/app/main.py"), "utf8");
  assert.match(map, /Consultar endereço e melhor rota/);
  assert.match(map, /Sugerir melhor rota/);
  assert.match(map, /Aplicar ordem sugerida/);
  assert.match(css, /@keyframes route-flow/);
  assert.match(api, /api\/map\/geocode/);
  assert.match(api, /api\/map\/optimize/);
});

test("document generator tolerates legacy state without templates", () => {
  const page = fs.readFileSync(path.join(root, "app/page.tsx"), "utf8");
  assert.match(page, /fallbackCompany/);
  assert.match(page, /fallbackTemplate/);
  assert.match(page, /templates = state\.settings\.documentTemplates\.length/);
  assert.match(page, /seedState\.settings\.documentTemplates/);
});
