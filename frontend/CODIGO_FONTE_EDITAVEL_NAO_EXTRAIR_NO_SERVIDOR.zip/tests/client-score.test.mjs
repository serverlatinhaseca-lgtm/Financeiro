import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import ts from "typescript";

const source = fs.readFileSync(new URL("../app/lib/client-score.ts", import.meta.url), "utf8");
const compiled = ts.transpileModule(source, {
  compilerOptions: { module: ts.ModuleKind.ESNext, target: ts.ScriptTarget.ES2022 },
}).outputText;
const { calculateClientScore } = await import(
  `data:text/javascript;base64,${Buffer.from(compiled).toString("base64")}`
);

const base = {
  id: "collection-1",
  clientId: "client-1",
  invoice: "100",
  dueDate: "2026-08-10",
  amount: 100,
  priority: "Verde",
  status: "Pendente",
  responsible: "Financeiro",
  nextContact: "2026-08-11",
  availableFrom: "2026-08-10",
  policyId: "default",
  attempts: 0,
  history: [],
};

test("cliente sem ocorrências inicia com score 1000", () => {
  assert.equal(calculateClientScore([], "2026-08-31"), 1000);
});

test("atraso e reagendamento reduzem o score", () => {
  const overdue = calculateClientScore([base], "2026-08-31");
  const rescheduled = calculateClientScore([{ ...base, status: "Reagendada" }], "2026-08-31");
  assert.ok(overdue < 1000);
  assert.ok(rescheduled < overdue);
});

test("pagamento pontual preserva score máximo", () => {
  const score = calculateClientScore([
    { ...base, status: "Paga", paidAt: "2026-08-10" },
  ], "2026-08-31");
  assert.equal(score, 1000);
});
