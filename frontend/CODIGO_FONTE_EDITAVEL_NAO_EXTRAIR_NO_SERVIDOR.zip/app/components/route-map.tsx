"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import {
  Crosshair,
  Check,
  Layers3,
  Loader2,
  MapPinned,
  Navigation,
  Route,
  Search,
  Sparkles,
  Truck,
  WandSparkles,
} from "lucide-react";
import { AppState, RouteRecord } from "@/app/lib/seed";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  NativeSelect,
  NativeSelectOption,
} from "@/components/ui/native-select";

const palette = [
  "#f97316",
  "#17324d",
  "#0284c7",
  "#16a34a",
  "#db2777",
  "#ca8a04",
];
const mapStyles = {
  clean: {
    label: "Claro elegante",
    url: "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
    attribution:
      '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
  },
  streets: {
    label: "Ruas detalhadas",
    url: "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
    attribution:
      '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
  },
  dark: {
    label: "Noturno roxo",
    url: "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
    attribution:
      '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
  },
} as const;

function hash(value: string) {
  return [...value].reduce(
    (total, character) => (total * 31 + character.charCodeAt(0)) >>> 0,
    7,
  );
}

function fallbackCoordinate(row: RouteRecord, index: number): [number, number] {
  const seed = hash(`${row.id}-${row.client}-${index}`);
  const angle = ((seed % 360) * Math.PI) / 180;
  const distance = 0.018 + ((seed >> 8) % 70) / 2200;
  return [
    -23.2237 + Math.sin(angle) * distance,
    -45.9009 + Math.cos(angle) * distance,
  ];
}

function routeLabel(value: string) {
  return value
    .replaceAll("-", " ")
    .replace(/\b\w/g, (character) => character.toUpperCase());
}

function routeKey(row?: RouteRecord) {
  if (!row) return "all";
  return [
    row.base || "sem-base",
    row.driver || "Sem motorista",
    row.trip || row.batch || "Viagem principal",
  ].join("|");
}

function minutesFromClock(value?: string) {
  if (!value || !/^\d{1,2}:\d{2}$/.test(value)) return null;
  const [hour, minute] = value.split(":").map(Number);
  return hour * 60 + minute;
}

function routeMetric(rows: RouteRecord[]) {
  const ordered = [...rows].sort(
    (a, b) =>
      (a.order || minutesFromClock(a.time) || 0) -
      (b.order || minutesFromClock(b.time) || 0),
  );
  const departure = ordered[0]?.time || "—";
  const arrival = ordered.at(-1)?.time || "—";
  const startMinutes = minutesFromClock(departure);
  let endMinutes = minutesFromClock(arrival);
  if (startMinutes !== null && endMinutes !== null && endMinutes < startMinutes)
    endMinutes += 24 * 60;
  const duration =
    startMinutes !== null && endMinutes !== null
      ? Math.max(20, endMinutes - startMinutes)
      : Math.max(20, ordered.length * 9);
  const drivingMinutes = Math.max(
    15,
    duration - Math.max(0, ordered.length - 1) * 4,
  );
  const distance = Math.max(4, Math.round((drivingMinutes / 60) * 28));
  return {
    departure,
    arrival,
    duration,
    distance,
    stops: ordered.length,
    ordered,
  };
}

function durationLabel(minutes: number) {
  const hours = Math.floor(minutes / 60);
  const rest = minutes % 60;
  return hours ? `${hours}h ${String(rest).padStart(2, "0")}min` : `${rest}min`;
}

type Commit = (action: string, recipe: (draft: AppState) => void) => void;
type GeocodeResult = {
  display_name: string;
  lat: number;
  lon: number;
  provider?: string;
};
type SuggestedRoute = {
  coordinates: [number, number][];
  distance: number;
  duration: number;
  order: number[];
};

export function RouteMap({ state, commit }: { state: AppState; commit: Commit }) {
  const mapElement = useRef<HTMLDivElement | null>(null);
  const mapInstance = useRef<import("leaflet").Map | null>(null);
  const [planId, setPlanId] = useState(() => routeKey(state.routes[0]));
  const [mapStyle, setMapStyle] = useState<keyof typeof mapStyles>("clean");
  const [selectedStop, setSelectedStop] = useState<RouteRecord | null>(null);
  const [addressQuery, setAddressQuery] = useState("");
  const [searching, setSearching] = useState(false);
  const [optimizing, setOptimizing] = useState(false);
  const [searchResults, setSearchResults] = useState<GeocodeResult[]>([]);
  const [searchedPlace, setSearchedPlace] = useState<GeocodeResult | null>(null);
  const [suggestedRoute, setSuggestedRoute] = useState<SuggestedRoute | null>(null);
  const [mapMessage, setMapMessage] = useState("");
  const routeGroups = useMemo(() => {
    const keys = [...new Set(state.routes.map(routeKey))];
    const bases = [
      ...new Set(state.routes.map((row) => row.base || "sem-base")),
    ];
    return keys.map((key, index) => {
      const rows = state.routes.filter((row) => routeKey(row) === key);
      const [base, driver, trip] = key.split("|");
      const baseIndex = bases.indexOf(base);
      return {
        key,
        label: `${driver} · ${trip}`,
        base: routeLabel(base),
        color:
          state.routePlans[baseIndex]?.color ||
          palette[baseIndex % palette.length] ||
          palette[index % palette.length],
        metric: routeMetric(rows),
      };
    });
  }, [state.routePlans, state.routes]);
  const visibleRows = useMemo(() => {
    if (planId === "all") {
      return routeGroups.flatMap((group) =>
        state.routes.filter((row) => routeKey(row) === group.key).slice(0, 5),
      );
    }
    return state.routes.filter((row) => routeKey(row) === planId).slice(0, 100);
  }, [planId, routeGroups, state.routes]);
  const currentMetric = useMemo(() => routeMetric(visibleRows), [visibleRows]);
  const selectedPosition = selectedStop
    ? currentMetric.ordered.findIndex((row) => row.id === selectedStop.id) + 1
    : 0;

  async function searchAddress(event: React.FormEvent) {
    event.preventDefault();
    if (addressQuery.trim().length < 4) return;
    setSearching(true);
    setMapMessage("");
    try {
      const query = addressQuery.trim();
      const cep = query.replace(/\D/g, "");
      let results: GeocodeResult[] = [];

      try {
        const response = await fetch(
          `/api/map/geocode?q=${encodeURIComponent(query)}`,
          { headers: { accept: "application/json" } },
        );
        if (response.ok) {
          const payload = (await response.json()) as { results?: GeocodeResult[] };
          results = payload.results || [];
        }
      } catch {
        // A busca segue para os provedores públicos abaixo.
      }

      if (!results.length && cep.length === 8) {
        try {
          const fallback = await fetch(`https://brasilapi.com.br/api/cep/v2/${cep}`);
          if (fallback.ok) {
            const found = (await fallback.json()) as {
              street?: string;
              neighborhood?: string;
              city?: string;
              state?: string;
              location?: { coordinates?: { latitude?: string; longitude?: string } };
            };
            const latitude = Number(found.location?.coordinates?.latitude);
            const longitude = Number(found.location?.coordinates?.longitude);
            if (Number.isFinite(latitude) && Number.isFinite(longitude)) {
              results = [{
                display_name: [found.street, found.neighborhood, found.city, found.state, cep]
                  .filter(Boolean)
                  .join(", "),
                lat: latitude,
                lon: longitude,
                provider: "BrasilAPI",
              }];
            }
          }
        } catch {
          // O próximo provedor ainda será tentado.
        }
      }

      if (!results.length) {
        try {
          const params = new URLSearchParams({
            format: "jsonv2",
            limit: "6",
            countrycodes: "br",
            q: query,
          });
          const osm = await fetch(
            `https://nominatim.openstreetmap.org/search?${params.toString()}`,
            { headers: { accept: "application/json" } },
          );
          if (osm.ok) {
            const payload = (await osm.json()) as Array<{
              display_name?: string;
              lat?: string;
              lon?: string;
            }>;
            results = payload
              .map((item) => ({
                display_name: item.display_name || query,
                lat: Number(item.lat),
                lon: Number(item.lon),
                provider: "OpenStreetMap",
              }))
              .filter((item) => Number.isFinite(item.lat) && Number.isFinite(item.lon));
          }
        } catch {
          // A mensagem amigável abaixo informa a indisponibilidade.
        }
      }
      setSearchResults(results);
      if (results.length === 1) {
        setSearchedPlace(results[0]);
        setSearchResults([]);
        setAddressQuery(results[0].display_name);
        setMapMessage(`Endereço localizado por ${results[0].provider || "mapa público"}.`);
      } else if (!results.length) {
        setMapMessage("Nenhum endereço encontrado.");
      }
    } catch {
      setMapMessage("Não foi possível localizar. Informe CEP ou endereço completo com cidade e UF.");
    } finally {
      setSearching(false);
    }
  }

  async function suggestBestRoute() {
    if (currentMetric.ordered.length < 2) {
      setMapMessage("Selecione uma rota com pelo menos duas paradas.");
      return;
    }
    setOptimizing(true);
    setMapMessage("");
    const points = currentMetric.ordered.map((row, index) => {
      const [latitude, longitude] =
        typeof row.latitude === "number" && typeof row.longitude === "number"
          ? [row.latitude, row.longitude]
          : fallbackCoordinate(row, index);
      return { latitude, longitude };
    });
    try {
      const response = await fetch("/api/map/optimize", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ points }),
      });
      if (!response.ok) throw new Error("Falha ao calcular rota");
      const payload = (await response.json()) as SuggestedRoute;
      setSuggestedRoute(payload);
      setMapMessage("Melhor sequência calculada com ruas e tempo de percurso.");
    } catch {
      setMapMessage("Não foi possível calcular a rota viária agora.");
    } finally {
      setOptimizing(false);
    }
  }

  function applySuggestedOrder() {
    if (!suggestedRoute) return;
    const orderedRows = suggestedRoute.order.map(
      (sourceIndex) => currentMetric.ordered[sourceIndex],
    );
    commit("Aplicou a melhor sequência de paradas", (draft) => {
      orderedRows.forEach((row, index) => {
        const target = draft.routes.find((item) => item.id === row?.id);
        if (target) target.order = index + 1;
      });
    });
    setMapMessage("Nova ordem aplicada à rota.");
  }

  useEffect(() => {
    let cancelled = false;
    async function renderMap() {
      if (!mapElement.current) return;
      const L = await import("leaflet");
      if (cancelled || !mapElement.current) return;
      mapInstance.current?.remove();
      const map = L.map(mapElement.current, {
        zoomControl: true,
        attributionControl: true,
        preferCanvas: false,
      }).setView([-23.2237, -45.9009], 11);
      mapInstance.current = map;
      map.createPane("routeFlowPane");
      const routePane = map.getPane("routeFlowPane");
      if (routePane) {
        routePane.style.zIndex = "460";
        routePane.style.pointerEvents = "none";
      }
      const tiles = mapStyles[mapStyle];
      L.tileLayer(tiles.url, {
        attribution: tiles.attribution,
        maxZoom: 19,
      }).addTo(map);
      const grouped = new Map<
        string,
        Array<{ row: RouteRecord; point: [number, number] }>
      >();
      visibleRows.forEach((row, index) => {
        const group = routeKey(row);
        const point: [number, number] =
          typeof row.latitude === "number" && typeof row.longitude === "number"
            ? [row.latitude, row.longitude]
            : fallbackCoordinate(row, index);
        grouped.set(group, [...(grouped.get(group) || []), { row, point }]);
      });
      const bounds: [number, number][] = [];
      [...grouped.entries()].forEach(([group, points], groupIndex) => {
        const color =
          routeGroups.find((routeGroup) => routeGroup.key === group)?.color ||
          palette[groupIndex % palette.length];
        const sorted = points.sort(
          (a, b) =>
            (a.row.order ?? minutesFromClock(a.row.time) ?? 0) -
            (b.row.order ?? minutesFromClock(b.row.time) ?? 0),
        );
        const coordinates = sorted.map((item) => item.point);
        bounds.push(...coordinates);
        const suggestedCoordinates =
          grouped.size === 1 && suggestedRoute?.coordinates.length
            ? suggestedRoute.coordinates
            : coordinates;
        if (suggestedCoordinates.length > 1) {
          const renderer = L.svg({ padding: 0.5, pane: "routeFlowPane" });
          L.polyline(suggestedCoordinates, {
            color: "#ffffff",
            weight: 12,
            opacity: 0.96,
            className: "route-line-halo",
            renderer,
          }).addTo(map).bringToFront();
          L.polyline(suggestedCoordinates, {
            color: "#17324d",
            weight: 7,
            opacity: 0.96,
            className: "route-line-base",
            renderer,
          }).addTo(map).bringToFront();
          L.polyline(suggestedCoordinates, {
            color: color || "#f97316",
            weight: 7,
            opacity: 1,
            dashArray: "4 18",
            className: "route-animated-line",
            renderer,
          }).addTo(map).bringToFront();
          bounds.push(...suggestedCoordinates);
        }
        sorted.forEach(({ row, point }, pointIndex) => {
          const marker = L.marker(point, {
            icon: L.divIcon({
              className: "route-leaflet-marker-wrap",
              html: `<span class="route-leaflet-marker" style="--marker:${color}"><b>${pointIndex + 1}</b></span>`,
              iconSize: [34, 34],
              iconAnchor: [17, 17],
            }),
          }).addTo(map);
          const groupLabel =
            routeGroups.find((routeGroup) => routeGroup.key === group)?.label ||
            routeLabel(group);
          marker.bindTooltip(`${row.client} · ${groupLabel}`, {
            direction: "top",
          });
          marker.on("click", () => setSelectedStop(row));
        });
      });
      if (searchedPlace) {
        const point: [number, number] = [searchedPlace.lat, searchedPlace.lon];
        bounds.push(point);
        L.marker(point, {
          icon: L.divIcon({
            className: "route-search-marker-wrap",
            html: '<span class="route-search-marker">⌖</span>',
            iconSize: [42, 42],
            iconAnchor: [21, 21],
          }),
        })
          .addTo(map)
          .bindPopup(`<strong>Endereço consultado</strong><br>${searchedPlace.display_name}`)
          .openPopup();
      }
      if (searchedPlace) {
        map.flyTo([searchedPlace.lat, searchedPlace.lon], 16, { duration: 0.8 });
      } else if (bounds.length) {
        map.fitBounds(bounds, { padding: [38, 38], maxZoom: 14 });
      }
      setTimeout(() => map.invalidateSize(), 80);
    }
    renderMap();
    return () => {
      cancelled = true;
      mapInstance.current?.remove();
      mapInstance.current = null;
    };
  }, [mapStyle, routeGroups, searchedPlace, suggestedRoute, visibleRows]);

  return (
    <div className="route-map-layout">
      <Card className="route-map-sidebar">
        <CardHeader>
          <div className="map-title-icon">
            <MapPinned />
          </div>
          <CardTitle>Mapa de distribuição</CardTitle>
          <CardDescription>
            Entregas de pães, congelados e produção organizadas em rotas
            personalizadas.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form className="map-address-search" onSubmit={searchAddress}>
            <label htmlFor="route-address-search">Consultar endereço e melhor rota</label>
            <div>
              <Search />
              <input
                id="route-address-search"
                value={addressQuery}
                onChange={(event) => setAddressQuery(event.target.value)}
                placeholder="Rua, número, cidade ou CEP"
              />
              <button type="submit" disabled={searching || addressQuery.trim().length < 4}>
                {searching ? <Loader2 className="animate-spin" /> : "Buscar"}
              </button>
            </div>
            {searchResults.length > 0 && (
              <div className="map-search-results">
                {searchResults.map((result) => (
                  <button
                    type="button"
                    key={`${result.lat}-${result.lon}`}
                    onClick={() => {
                      setSearchedPlace(result);
                      setSearchResults([]);
                      setAddressQuery(result.display_name);
                    }}
                  >
                    <MapPinned /> <span>{result.display_name}</span>
                  </button>
                ))}
              </div>
            )}
          </form>
          <div className="map-style-control">
            <span>
              <Layers3 /> Estilo do mapa
            </span>
            <div>
              {(Object.keys(mapStyles) as Array<keyof typeof mapStyles>).map(
                (key) => (
                  <button
                    key={key}
                    type="button"
                    className={mapStyle === key ? "active" : ""}
                    onClick={() => setMapStyle(key)}
                  >
                    {mapStyles[key].label}
                  </button>
                ),
              )}
            </div>
          </div>
          <NativeSelect
            value={planId}
            onChange={(event) => setPlanId(event.target.value)}
          >
            <NativeSelectOption value="all">Todas as rotas</NativeSelectOption>
            {routeGroups.map((group) => (
              <NativeSelectOption key={group.key} value={group.key}>
                {group.base} · {group.label}
              </NativeSelectOption>
            ))}
          </NativeSelect>
          <div className="map-route-actions">
            <button type="button" onClick={suggestBestRoute} disabled={optimizing}>
              {optimizing ? <Loader2 className="animate-spin" /> : <WandSparkles />}
              {optimizing ? "Calculando..." : "Sugerir melhor rota"}
            </button>
            {suggestedRoute && (
              <button type="button" className="secondary" onClick={applySuggestedOrder}>
                <Check /> Aplicar ordem sugerida
              </button>
            )}
          </div>
          {mapMessage && <p className="map-feedback">{mapMessage}</p>}
          <div className="map-flow-status">
            <span><i /> Fluxo animado ativo</span>
            <small>A linha segue a ordem numérica de todas as paradas da rota.</small>
          </div>
          <div className="map-trip-summary">
            <div>
              <Navigation />
              <span>
                <small>Distância estimada</small>
                <strong>{suggestedRoute?.distance ?? currentMetric.distance} km</strong>
              </span>
            </div>
            <div>
              <Crosshair />
              <span>
                <small>Tempo de percurso</small>
                <strong>{durationLabel(suggestedRoute?.duration ?? currentMetric.duration)}</strong>
              </span>
            </div>
            <div>
              <MapPinned />
              <span>
                <small>Paradas exibidas</small>
                <strong>{currentMetric.stops}</strong>
              </span>
            </div>
            <div>
              <Truck />
              <span>
                <small>Saída → chegada</small>
                <strong>
                  {currentMetric.departure} → {currentMetric.arrival}
                </strong>
              </span>
            </div>
          </div>
          <div className="map-route-legend">
            {routeGroups.map((group) => (
              <button
                type="button"
                key={group.key}
                onClick={() => setPlanId(group.key)}
                className={planId === group.key ? "active" : ""}
              >
                <i style={{ background: group.color }} />
                <span>
                  <strong>{group.label}</strong>
                  <small>
                    {group.base} · {group.metric.stops} paradas ·{" "}
                    {group.metric.distance} km ·{" "}
                    {durationLabel(group.metric.duration)}
                  </small>
                </span>
                <Route />
              </button>
            ))}
          </div>
          <div className="map-note">
            <Crosshair />
            <span>
              <strong>Coordenadas reais quando cadastradas</strong>
              <small>
                Paradas ainda sem latitude/longitude aparecem em posição
                estimada até completar o endereço.
              </small>
            </span>
          </div>
          <div className="map-beauty-note">
            <Sparkles />
            <span>
              As cores podem ser alteradas em{" "}
              <strong>Rotas → Editar → Cor da rota</strong>.
            </span>
          </div>
        </CardContent>
      </Card>
      <Card className="route-live-map-card">
        <CardContent>
          <div
            ref={mapElement}
            className={`route-live-map map-style-${mapStyle}`}
          />
        </CardContent>
      </Card>
      {selectedStop && (
        <aside className="map-stop-detail">
          <button onClick={() => setSelectedStop(null)} aria-label="Fechar">
            ×
          </button>
          <MapPinned />
          <span>
            <small>
              PARADA {selectedPosition || "—"} DE {currentMetric.stops}
            </small>
            <h3>{selectedStop.client}</h3>
            <p>{selectedStop.address || "Endereço ainda não informado"}</p>
            <div>
              <em>
                <Route /> {routeLabel(selectedStop.base || "sem rota")} ·{" "}
                {selectedStop.driver || "Motorista a definir"}
              </em>
              <em>
                <Truck /> {selectedStop.driver || "Motorista a definir"}
              </em>
              <em>
                <Navigation /> Previsão {selectedStop.time || "a definir"}
              </em>
              <em>
                <Crosshair />{" "}
                {selectedStop.trip || selectedStop.batch || "Viagem principal"}
              </em>
            </div>
          </span>
        </aside>
      )}
    </div>
  );
}
