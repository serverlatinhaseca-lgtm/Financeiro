import type { Collection } from "@/app/lib/seed";

function dateDistance(from: string, to: string) {
  const start = new Date(`${from}T12:00:00`).getTime();
  const end = new Date(`${to}T12:00:00`).getTime();
  if (!Number.isFinite(start) || !Number.isFinite(end)) return 0;
  return Math.max(0, Math.floor((end - start) / 86_400_000));
}

export function calculateClientScore(
  collections: Collection[],
  referenceDate = new Date().toISOString().slice(0, 10),
) {
  let score = 1000;

  collections.forEach((item) => {
    const overdueDays = dateDistance(item.dueDate, referenceDate);
    const paidLateDays = item.paidAt
      ? dateDistance(item.dueDate, item.paidAt.slice(0, 10))
      : 0;
    const settled = ["Paga", "Baixada", "Arquivada"].includes(item.status);

    if (!settled && overdueDays > 0) {
      score -= 95 + Math.min(overdueDays * 4, 180);
    }
    if (settled && paidLateDays > 0) {
      score -= Math.min(30 + paidLateDays * 3, 140);
    }
    if (item.status === "Reagendada") score -= 55;
    if (["Cancelamento pendente", "Cancelado"].includes(item.status)) {
      score -= 150;
    }
    score -= Math.min((item.attempts || 0) * 7, 42);
  });

  return Math.max(0, Math.min(1000, Math.round(score)));
}
