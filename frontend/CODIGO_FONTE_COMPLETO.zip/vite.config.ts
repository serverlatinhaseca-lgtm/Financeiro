import vinext from "vinext";
import { defineConfig } from "vite";

// Build de produção do Gestão Operacional.
// O frontend é servido em Docker/Node, portanto não depende dos plugins
// internos do ambiente Site Creator/Cloudflare usados apenas no preview original.
export default defineConfig({
  server: {
    host: "0.0.0.0",
  },
  plugins: [vinext()],
});
