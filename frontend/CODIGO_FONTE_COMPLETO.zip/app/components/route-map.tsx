"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import {
  Crosshair,
  Check,
  Layers3,
  Loader2,
  MapPinned,
  Navigation,
  Route,
  Search,
  Sparkles,
  Truck,
  WandSparkles,
} from "lucide-react";
import { AppState, RouteRecord } from "@/app/lib/seed";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  NativeSelect,
  NativeSelectOption,
} from "@/components/ui/native-select";

const palette = [
  "#6741e8",
  "#f97316",
  "#0284c7",
  "#16a34a",
  "#db2777",
  "#ca8a04",
];
const mapStyles = {
  clean: {
    label: "Claro elegante",
    url: "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
    attribution:
      '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
  },
  streets: {
    label: "Ruas detalhadas",
    url: "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
    attribution:
      '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
  },
  dark: {
    label: "Noturno roxo",
    url: "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
    attribution:
      '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
  },
} as const;

function hash(value: string) {
  return [...value].reduce(
    (total, character) => (total * 31 + character.charCodeAt(0)) >>> 0,
    7,
  );
}

function fallbackCoordinate(row: RouteRecord, index: number): [number, number] {
  const seed = hash(`${row.id}-${row.client}-${index}`);
  const angle = ((seed % 360) * Math.PI) / 180;
  const distance = 0.018 + ((seed >> 8) % 70) / 2200;
  return [
    -23.2237 + Math.sin(angle) * distance,
    -45.9009 + Math.cos(angle) * distance,
  ];
}

function routeLabel(value: string) {
  return value
    .replaceAll("-", " ")
    .replace(/\b\w/g, (character) => character.toUpperCase());
}

function routeKey(row?: RouteRecord) {
  if (!row) return "all";
  return [
    row.base || "sem-base",
    row.driver || "Sem motorista",
    row.trip || row.batch || "Viagem principal",
  ].join("|");
}

function minutesFromClock(value?: string) {
  if (!value || !/^\d{1,2}:\d{2}$/.test(value)) return null;
  const [hour, minute] = value.split(":").map(Number);
  return hour * 60 + minute;
}

function routeMetric(rows: RouteRecord[]) {
  const ordered = [...rows].sort(
    (a, b) =>
      (a.order || minutesFromClock(a.time) || 0) -
      (b.order || minutesFromClock(b.time) || 0),
  );
  const departure = ordered[0]?.time || "—";
  const arrival = ordered.at(-1)?.time || "—";
  const startMinutes = minutesFromClock(departure);
  let endMinutes = minutesFromClock(arrival);
  if (startMinutes !== null && endMinutes !== null && endMinutes < startMinutes)
    endMinutes += 24 * 60;
  const duration =
    startMinutes !== null && endMinutes !== null
      ? Math.max(20, endMinutes - startMinutes)
      : Math.max(20, ordered.length * 9);
  const drivingMinutes = Math.max(
    15,
    duration - Math.max(0, ordered.length - 1) * 4,
  );
  const distance = Math.max(4, Math.round((drivingMinutes / 60) * 28));
  return {
    departure,
    arrival,
    duration,
    distance,
    stops: ordered.length,
    ordered,
  };
}


function distanceKm(a: [number, number], b: [number, number]) {
  const toRad = (value: number) => (value * Math.PI) / 180;
  const earth = 6371;
  const dLat = toRad(b[0] - a[0]);
  const dLon = toRad(b[1] - a[1]);
  const lat1 = toRad(a[0]);
  const lat2 = toRad(b[0]);
  const h =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLon / 2) ** 2;
  return 2 * earth * Math.asin(Math.sqrt(h));
}

function durationLabel(minutes: number) {
  const hours = Math.floor(minutes / 60);
  const rest = minutes % 60;
  return hours ? `${hours}h ${String(rest).padStart(2, "0")}min` : `${rest}min`;
}

type Commit = (action: string, recipe: (draft: AppState) => void) => void;
type GeocodeResult = {
  display_name: string;
  lat: number;
  lon: number;
};
type SuggestedRoute = {
  coordinates: [number, number][];
  distance: number;
  duration: number;
  order: number[];
};

export function RouteMap({ state, commit }: { state: AppState; commit: Commit }) {
  const mapElement = useRef<HTMLDivElement | null>(null);
  const mapInstance = useRef<import("leaflet").Map | null>(null);
  const [planId, setPlanId] = useState(() => routeKey(state.routes[0]));
  const [mapStyle, setMapStyle] = useState<keyof typeof mapStyles>("clean");
  const [selectedStop, setSelectedStop] = useState<RouteRecord | null>(null);
  const [addressQuery, setAddressQuery] = useState("");
  const [searching, setSearching] = useState(false);
  const [optimizing, setOptimizing] = useState(false);
  const [searchResults, setSearchResults] = useState<GeocodeResult[]>([]);
  const [searchedPlace, setSearchedPlace] = useState<GeocodeResult | null>(null);
  const [suggestedRoute, setSuggestedRoute] = useState<SuggestedRoute | null>(null);
  const [mapMessage, setMapMessage] = useState("");
  const routeGroups = useMemo(() => {
    const keys = [...new Set(state.routes.map(routeKey))];
    const bases = [
      ...new Set(state.routes.map((row) => row.base || "sem-base")),
    ];
    return keys.map((key, index) => {
      const rows = state.routes.filter((row) => routeKey(row) === key);
      const [base, driver, trip] = key.split("|");
      const baseIndex = bases.indexOf(base);
      return {
        key,
        label: `${driver} · ${trip}`,
        base: routeLabel(base),
        color:
          state.routePlans[baseIndex]?.color ||
          palette[baseIndex % palette.length] ||
          palette[index % palette.length],
        metric: routeMetric(rows),
      };
    });
  }, [state.routePlans, state.routes]);
  const visibleRows = useMemo(() => {
    if (planId === "all") {
      return routeGroups.flatMap((group) =>
        state.routes.filter((row) => routeKey(row) === group.key).slice(0, 5),
      );
    }
    return state.routes.filter((row) => routeKey(row) === planId).slice(0, 100);
  }, [planId, routeGroups, state.routes]);
  const currentMetric = useMemo(() => routeMetric(visibleRows), [visibleRows]);
  const selectedPosition = selectedStop
    ? currentMetric.ordered.findIndex((row) => row.id === selectedStop.id) + 1
    : 0;
  const addressRouteRecommendation = useMemo(() => {
    if (!searchedPlace || !routeGroups.length) return null;
    const searched: [number, number] = [searchedPlace.lat, searchedPlace.lon];
    const ranked = routeGroups
      .map((group) => {
        const rows = state.routes.filter((row) => routeKey(row) === group.key);
        const distances = rows.map((row, index) => {
          const point: [number, number] =
            typeof row.latitude === "number" && typeof row.longitude === "number"
              ? [row.latitude, row.longitude]
              : fallbackCoordinate(row, index);
          return distanceKm(searched, point);
        });
        return { ...group, distance: Math.min(...distances) };
      })
      .sort((a, b) => a.distance - b.distance);
    return ranked[0] || null;
  }, [routeGroups, searchedPlace, state.routes]);

  async function searchAddress(event: React.FormEvent) {
    event.preventDefault();
    if (addressQuery.trim().length < 4) return;
    setSearching(true);
    setMapMessage("");
    try {
      const response = await fetch(
        `/api/map/geocode?q=${encodeURIComponent(addressQuery.trim())}`,
      );
      if (!response.ok) throw new Error("Não foi possível consultar o endereço");
      const payload = (await response.json()) as { results: GeocodeResult[] };
      setSearchResults(payload.results || []);
      if (!payload.results?.length) setMapMessage("Nenhum endereço encontrado.");
    } catch {
      setMapMessage("A consulta de endereço está indisponível no momento.");
    } finally {
      setSearching(false);
    }
  }

  async function suggestBestRoute() {
    if (currentMetric.ordered.length < 2) {
      setMapMessage("Selecione uma rota com pelo menos duas paradas.");
      return;
    }
    setOptimizing(true);
    setMapMessage("");
    const points = currentMetric.ordered.map((row, index) => {
      const [latitude, longitude] =
        typeof row.latitude === "number" && typeof row.longitude === "number"
          ? [row.latitude, row.longitude]
          : fallbackCoordinate(row, index);
      return { latitude, longitude };
    });
    try {
      const response = await fetch("/api/map/optimize", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ points }),
      });
      if (!response.ok) throw new Error("Falha ao calcular rota");
      const payload = (await response.json()) as SuggestedRoute;
      setSuggestedRoute(payload);
      setMapMessage("Melhor sequência calculada com ruas e tempo de percurso.");
    } catch {
      setMapMessage("Não foi possível calcular a rota viária agora.");
    } finally {
      setOptimizing(false);
    }
  }

  function applySuggestedOrder() {
    if (!suggestedRoute) return;
    const orderedRows = suggestedRoute.order.map(
      (sourceIndex) => currentMetric.ordered[sourceIndex],
    );
    commit("Aplicou a melhor sequência de paradas", (draft) => {
      orderedRows.forEach((row, index) => {
        const target = draft.routes.find((item) => item.id === row?.id);
        if (target) target.order = index + 1;
      });
    });
    setMapMessage("Nova ordem aplicada à rota.");
  }

  useEffect(() => {
    let cancelled = false;
    async function renderMap() {
      if (!mapElement.current) return;
      const L = await import("leaflet");
      if (cancelled || !mapElement.current) return;
      mapInstance.current?.remove();
      const map = L.map(mapElement.current, {
        zoomControl: true,
        attributionControl: true,
      }).setView([-23.2237, -45.9009], 11);
      mapInstance.current = map;
      const tiles = mapStyles[mapStyle];
      L.tileLayer(tiles.url, {
        attribution: tiles.attribution,
        maxZoom: 19,
      }).addTo(map);
      const grouped = new Map<
        string,
        Array<{ row: RouteRecord; point: [number, number] }>
      >();
      visibleRows.forEach((row, index) => {
        const group = routeKey(row);
        const point: [number, number] =
          typeof row.latitude === "number" && typeof row.longitude === "number"
            ? [row.latitude, row.longitude]
            : fallbackCoordinate(row, index);
        grouped.set(group, [...(grouped.get(group) || []), { row, point }]);
      });
      const bounds: [number, number][] = [];
      [...grouped.entries()].forEach(([group, points], groupIndex) => {
        const color =
          routeGroups.find((routeGroup) => routeGroup.key === group)?.color ||
          palette[groupIndex % palette.length];
        const sorted = points.sort(
          (a, b) => (a.row.order || 0) - (b.row.order || 0),
        );
        const coordinates = sorted.map((item) => item.point);
        bounds.push(...coordinates);
        const suggestedCoordinates =
          grouped.size === 1 && suggestedRoute?.coordinates.length
            ? suggestedRoute.coordinates
            : coordinates;
        if (suggestedCoordinates.length > 1) {
          L.polyline(suggestedCoordinates, {
            color: "#ffffff",
            weight: 9,
            opacity: 0.88,
            className: "route-line-halo",
          }).addTo(map);
          L.polyline(suggestedCoordinates, {
            color,
            weight: 5,
            opacity: 0.98,
            dashArray: "13 10",
            className: "route-animated-line",
          }).addTo(map);
          bounds.push(...suggestedCoordinates);
        }
        sorted.forEach(({ row, point }, pointIndex) => {
          const marker = L.marker(point, {
            icon: L.divIcon({
              className: "route-leaflet-marker-wrap",
              html: `<span class="route-leaflet-marker" style="--marker:${color}"><b>${pointIndex + 1}</b></span>`,
              iconSize: [34, 34],
              iconAnchor: [17, 17],
            }),
          }).addTo(map);
          const groupLabel =
            routeGroups.find((routeGroup) => routeGroup.key === group)?.label ||
            routeLabel(group);
          marker.bindTooltip(`${row.client} · ${groupLabel}`, {
            direction: "top",
          });
          marker.on("click", () => setSelectedStop(row));
        });
      });
      if (searchedPlace) {
        const point: [number, number] = [searchedPlace.lat, searchedPlace.lon];
        bounds.push(point);
        L.marker(point, {
          icon: L.divIcon({
            className: "route-search-marker-wrap",
            html: '<span class="route-search-marker">⌖</span>',
            iconSize: [42, 42],
            iconAnchor: [21, 21],
          }),
        })
          .addTo(map)
          .bindPopup(`<strong>Endereço consultado</strong><br>${searchedPlace.display_name}`)
          .openPopup();
      }
      if (bounds.length)
        map.fitBounds(bounds, { padding: [38, 38], maxZoom: 14 });
      setTimeout(() => map.invalidateSize(), 80);
    }
    renderMap();
    return () => {
      cancelled = true;
      mapInstance.current?.remove();
      mapInstance.current = null;
    };
  }, [mapStyle, routeGroups, searchedPlace, suggestedRoute, visibleRows]);

  return (
    <div className="route-map-layout">
      <Card className="route-map-sidebar">
        <CardHeader>
          <div className="map-title-icon">
            <MapPinned />
          </div>
          <CardTitle>Mapa de distribuição</CardTitle>
          <CardDescription>
            Entregas de pães, congelados e produção organizadas em rotas
            personalizadas.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form className="map-address-search" onSubmit={searchAddress}>
            <label htmlFor="route-address-search">Consultar endereço e melhor rota</label>
            <div>
              <Search />
              <input
                id="route-address-search"
                value={addressQuery}
                onChange={(event) => setAddressQuery(event.target.value)}
                placeholder="Rua, número, cidade ou CEP"
              />
              <button type="submit" disabled={searching || addressQuery.trim().length < 4}>
                {searching ? <Loader2 className="animate-spin" /> : "Buscar"}
              </button>
            </div>
            {searchResults.length > 0 && (
              <div className="map-search-results">
                {searchResults.map((result) => (
                  <button
                    type="button"
                    key={`${result.lat}-${result.lon}`}
                    onClick={() => {
                      setSearchedPlace(result);
                      setSearchResults([]);
                      setAddressQuery(result.display_name);
                    }}
                  >
                    <MapPinned /> <span>{result.display_name}</span>
                  </button>
                ))}
              </div>
            )}
            {addressRouteRecommendation && (
              <div className="map-route-recommendation">
                <Sparkles />
                <div>
                  <small>Melhor rota para este endereço</small>
                  <strong>{addressRouteRecommendation.base} · {addressRouteRecommendation.label}</strong>
                  <span>Parada mais próxima a aproximadamente {addressRouteRecommendation.distance.toFixed(1)} km.</span>
                </div>
                <button type="button" onClick={() => setPlanId(addressRouteRecommendation.key)}>Ver rota</button>
              </div>
            )}
          </form>
          <div className="map-style-control">
            <span>
              <Layers3 /> Estilo do mapa
            </span>
            <div>
              {(Object.keys(mapStyles) as Array<keyof typeof mapStyles>).map(
                (key) => (
                  <button
                    key={key}
                    type="button"
                    className={mapStyle === key ? "active" : ""}
                    onClick={() => setMapStyle(key)}
                  >
                    {mapStyles[key].label}
                  </button>
                ),
              )}
            </div>
          </div>
          <NativeSelect
            value={planId}
            onChange={(event) => setPlanId(event.target.value)}
          >
            <NativeSelectOption value="all">Todas as rotas</NativeSelectOption>
            {routeGroups.map((group) => (
              <NativeSelectOption key={group.key} value={group.key}>
                {group.base} · {group.label}
              </NativeSelectOption>
            ))}
          </NativeSelect>
          <div className="map-route-actions">
            <button type="button" onClick={suggestBestRoute} disabled={optimizing}>
              {optimizing ? <Loader2 className="animate-spin" /> : <WandSparkles />}
              {optimizing ? "Calculando..." : "Sugerir melhor rota"}
            </button>
            {suggestedRoute && (
              <button type="button" className="secondary" onClick={applySuggestedOrder}>
                <Check /> Aplicar ordem sugerida
              </button>
            )}
          </div>
          {mapMessage && <p className="map-feedback">{mapMessage}</p>}
          <div className="map-trip-summary">
            <div>
              <Navigation />
              <span>
                <small>Distância estimada</small>
                <strong>{suggestedRoute?.distance ?? currentMetric.distance} km</strong>
              </span>
            </div>
            <div>
              <Crosshair />
              <span>
                <small>Tempo de percurso</small>
                <strong>{durationLabel(suggestedRoute?.duration ?? currentMetric.duration)}</strong>
              </span>
            </div>
            <div>
              <MapPinned />
              <span>
                <small>Paradas exibidas</small>
                <strong>{currentMetric.stops}</strong>
              </span>
            </div>
            <div>
              <Truck />
              <span>
                <small>Saída → chegada</small>
                <strong>
                  {currentMetric.departure} → {currentMetric.arrival}
                </strong>
              </span>
            </div>
          </div>
          <div className="map-route-legend">
            {routeGroups.map((group) => (
              <button
                type="button"
                key={group.key}
                onClick={() => setPlanId(group.key)}
                className={planId === group.key ? "active" : ""}
              >
                <i style={{ background: group.color }} />
                <span>
                  <strong>{group.label}</strong>
                  <small>
                    {group.base} · {group.metric.stops} paradas ·{" "}
                    {group.metric.distance} km ·{" "}
                    {durationLabel(group.metric.duration)}
                  </small>
                </span>
                <Route />
              </button>
            ))}
          </div>
          <div className="map-note">
            <Crosshair />
            <span>
              <strong>Coordenadas reais quando cadastradas</strong>
              <small>
                Paradas ainda sem latitude/longitude aparecem em posição
                estimada até completar o endereço.
              </small>
            </span>
          </div>
          <div className="map-beauty-note">
            <Sparkles />
            <span>
              As cores podem ser alteradas em{" "}
              <strong>Rotas → Editar → Cor da rota</strong>.
            </span>
          </div>
        </CardContent>
      </Card>
      <Card className="route-live-map-card">
        <CardContent>
          <div
            ref={mapElement}
            className={`route-live-map map-style-${mapStyle}`}
          />
        </CardContent>
      </Card>
      {selectedStop && (
        <aside className="map-stop-detail">
          <button onClick={() => setSelectedStop(null)} aria-label="Fechar">
            ×
          </button>
          <MapPinned />
          <span>
            <small>
              PARADA {selectedPosition || "—"} DE {currentMetric.stops}
            </small>
            <h3>{selectedStop.client}</h3>
            <p>{selectedStop.address || "Endereço ainda não informado"}</p>
            <div>
              <em>
                <Route /> {routeLabel(selectedStop.base || "sem rota")} ·{" "}
                {selectedStop.driver || "Motorista a definir"}
              </em>
              <em>
                <Truck /> {selectedStop.driver || "Motorista a definir"}
              </em>
              <em>
                <Navigation /> Previsão {selectedStop.time || "a definir"}
              </em>
              <em>
                <Crosshair />{" "}
                {selectedStop.trip || selectedStop.batch || "Viagem principal"}
              </em>
            </div>
          </span>
        </aside>
      )}
    </div>
  );
}
