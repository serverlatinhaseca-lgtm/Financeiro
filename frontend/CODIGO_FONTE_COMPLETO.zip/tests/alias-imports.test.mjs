import test from "node:test"
import assert from "node:assert/strict"
import fs from "node:fs"
import path from "node:path"

const root = process.cwd()
const exts = ["", ".ts", ".tsx", ".js", ".jsx", ".mjs"]

function existsAlias(target) {
  const base = path.join(root, target.slice(2))
  if (exts.some((ext) => fs.existsSync(base + ext))) return true
  return ["index.ts", "index.tsx", "index.js", "index.jsx"].some((name) => fs.existsSync(path.join(base, name)))
}

function walk(dir, out = []) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (["node_modules", "dist", ".git"].includes(entry.name)) continue
    const full = path.join(dir, entry.name)
    if (entry.isDirectory()) walk(full, out)
    else if (/\.(?:ts|tsx|js|jsx|mjs)$/.test(entry.name)) out.push(full)
  }
  return out
}

test("todos os imports @/ apontam para arquivos presentes no pacote", () => {
  const missing = []
  const pattern = /(?:from\s+|import\s*\(?\s*)["'](@\/[^"']+)["']/g
  for (const file of walk(root)) {
    const text = fs.readFileSync(file, "utf8")
    for (const match of text.matchAll(pattern)) {
      if (!existsAlias(match[1])) missing.push(`${path.relative(root, file)} -> ${match[1]}`)
    }
  }
  assert.deepEqual(missing, [])
})
