import assert from "node:assert/strict";
import fs from "node:fs";
import test from "node:test";

const read = (path) => fs.readFileSync(new URL(`../${path}`, import.meta.url), "utf8");
const seed = read("app/lib/seed.ts");
const page = read("app/page.tsx");
const css = read("app/globals.css");
const map = read("app/components/route-map.tsx");
const routes = read("app/components/route-operations-center.tsx");
const finance = read("app/lib/finance-rules.ts");

test("tema claro usa as cores da marca e dark mode usa roxos", () => {
  assert.match(seed, /primary:\s*"#c96520"/);
  assert.match(seed, /secondary:\s*"#18263f"/);
  assert.match(seed, /background:\s*"#f6f1e9"/);
  assert.match(seed, /darkBackground:\s*"#120d24"/);
  assert.match(css, /--ne-orange:\s*#c96520/);
  assert.match(css, /\.dark-mode[\s\S]*#120b22/);
});

test("clientes novos partem de score 1000 e score financeiro é calculado", () => {
  assert.match(page, /score:\s*1000/);
  assert.match(finance, /export function calculateClientScore/);
  assert.match(finance, /overduePenalty/);
  assert.match(page, /Ver como o score foi calculado/);
});

test("mapa usa apenas coordenadas reais e tem geocodificação, recomendação e linha animada", () => {
  assert.doesNotMatch(map, /fallbackCoordinate/);
  assert.doesNotMatch(map, /function hash\(/);
  assert.match(map, /\/api\/map\/geocode/);
  assert.match(map, /Localizar paradas/);
  assert.match(map, /addressRouteRecommendation/);
  assert.match(map, /Melhor rota para este endereço/);
  assert.match(map, /route-animated-line/);
  assert.match(map, /Satélite/);
});

test("planner de rotas é compacto e abre detalhes em modal", () => {
  assert.match(routes, /title="Planner operacional"[\s\S]*compact[\s\S]*onSelect=\{setSelectedPlannerEvent\}/);
  assert.match(routes, /planner-event-dialog/);
  assert.match(routes, /Abrir cadastro relacionado/);
});

test("gerador de documentos salva snapshot e reabre preview sem página vazia", () => {
  assert.match(seed, /items\?:\s*\{/);
  assert.match(page, /Documento pronto/);
  assert.match(page, /setPreview\(true\)/);
  assert.match(page, /templateId/);
});

test("busca global e login por usuário ou e-mail são funcionais", () => {
  assert.match(page, /globalSearch/);
  assert.match(page, /global-search-results/);
  assert.match(page, /account\.email\?\.toLowerCase\(\) === username\.toLowerCase\(\)/);
});

test("layout profissional foi aplicado globalmente e otimizado para zoom 100%", () => {
  assert.match(css, /SISTEMA VISUAL PROFISSIONAL V3/);
  assert.match(css, /@media \(max-width: 1440px\)/);
  assert.match(css, /\.sidebar/);
  assert.match(css, /\.profile-sheet/);
  assert.match(css, /\.route-command-head/);
});

test("cadastro de cliente consulta CEP e CNPJ e grupos possuem CRUD", () => {
  assert.match(page, /\/api\/lookup\/cep\/\$\{cep\}/);
  assert.match(page, /\/api\/lookup\/cnpj\/\$\{cnpj\}/);
  assert.match(page, /Editar grupo/);
  assert.match(page, /customerGroups\.filter/);
});

test("central de rotas mantém operações críticas editáveis pela interface", () => {
  for (const label of [
    "Base mensal", "Consulta para cadastro", "Próximo mês", "Mapa", "Clientes e paradas",
    "Motoristas", "Feriados", "Conferência", "Pendências", "Histórico e versões", "Indicadores", "Relatórios", "Configurações",
  ]) assert.match(routes, new RegExp(label));
  assert.match(routes, /Mover para rota/);
  assert.match(routes, /Novo motorista/);
  assert.match(routes, /Registrar divergência/);
  assert.match(routes, /Concluir competência/);
});

test("a aba de importação redundante não faz parte da navegação de clientes", () => {
  const clientSection = page.slice(page.indexOf('function ClientsModule'), page.indexOf('function ClientProfile'));
  assert.doesNotMatch(clientSection, /value="importacao"/i);
});
