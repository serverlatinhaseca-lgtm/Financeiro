import assert from "node:assert/strict";
import fs from "node:fs";
import test from "node:test";

const page = fs.readFileSync(new URL("../app/page.tsx", import.meta.url), "utf8");
const css = fs.readFileSync(new URL("../app/globals.css", import.meta.url), "utf8");

test("release R3 is visible and layout is protected at 100 percent zoom", () => {
  assert.match(page, /2026\.08\.31-R3-FULLSTACK/);
  assert.match(css, /RELEASE R3/);
  assert.match(css, /overflow-x:\s*hidden/);
});
